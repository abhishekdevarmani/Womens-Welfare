-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 27, 2022 at 08:27 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wwa_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_details`
--

DROP TABLE IF EXISTS `bank_details`;
CREATE TABLE IF NOT EXISTS `bank_details` (
  `b_id` int(100) NOT NULL AUTO_INCREMENT,
  `b_name` varchar(100) NOT NULL,
  `b_ac_holder` varchar(100) NOT NULL,
  `b_cardnumber` varchar(100) NOT NULL,
  `b_spin` varchar(100) NOT NULL,
  `b_amount` varchar(100) NOT NULL,
  `b_status` varchar(100) NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank_details`
--

INSERT INTO `bank_details` (`b_id`, `b_name`, `b_ac_holder`, `b_cardnumber`, `b_spin`, `b_amount`, `b_status`) VALUES
(1, 'HDFC Bank', 'sangeeta@gmail.com', '5588774455588585', '1221', '90000', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `donation_details`
--

DROP TABLE IF EXISTS `donation_details`;
CREATE TABLE IF NOT EXISTS `donation_details` (
  `d_id` int(100) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) NOT NULL,
  `w_id` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`d_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donation_details`
--

INSERT INTO `donation_details` (`d_id`, `u_id`, `w_id`, `amount`, `date`) VALUES
(1, 'sangeeta@gmail.com', 'info.sakhiorg@gmail.com', '10000', '27-8-2022');

-- --------------------------------------------------------

--
-- Table structure for table `evidence_details`
--

DROP TABLE IF EXISTS `evidence_details`;
CREATE TABLE IF NOT EXISTS `evidence_details` (
  `ev_id` int(100) NOT NULL AUTO_INCREMENT,
  `c_id` varchar(100) NOT NULL,
  `ev_link` varchar(100) NOT NULL,
  `upload_date` varchar(100) NOT NULL,
  PRIMARY KEY (`ev_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `evidence_details`
--

INSERT INTO `evidence_details` (`ev_id`, `c_id`, `ev_link`, `upload_date`) VALUES
(1, '1', 'report.jpg', '2022-8-27');

-- --------------------------------------------------------

--
-- Table structure for table `feedback_details`
--

DROP TABLE IF EXISTS `feedback_details`;
CREATE TABLE IF NOT EXISTS `feedback_details` (
  `f_id` int(100) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) NOT NULL,
  `w_id` varchar(100) NOT NULL,
  `feedback` varchar(100) NOT NULL,
  `senddate` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback_details`
--

INSERT INTO `feedback_details` (`f_id`, `u_id`, `w_id`, `feedback`, `senddate`, `status`) VALUES
(1, 'sangeeta@gmail.com', 'info.sakhiorg@gmail.com', 'Testing Feedback from User', '2022-8-27', 'New');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `utype` varchar(100) NOT NULL,
  `s_qstn` varchar(100) NOT NULL,
  `s_ans` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `utype`, `s_qstn`, `s_ans`, `status`) VALUES
('admin', 'admin123', 'admin', 'Fev. Place?', 'Goa', 'active'),
('info.sakhiorg@gmail.com', '9988776655', 'welfare', 'Enter Last 4 Digits of Reg No.', '6655', 'active'),
('laxmi@gmail.com', '9966447788', 'user', 'Enter Last 4 Digits of Reg. Mobile No.', '7788', 'active'),
('sangeeta@gmail.com', '9517531230', 'user', 'Enter Last 4 Digits of Reg. Mobile No.', '1230', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `notice_details`
--

DROP TABLE IF EXISTS `notice_details`;
CREATE TABLE IF NOT EXISTS `notice_details` (
  `n_id` int(100) NOT NULL AUTO_INCREMENT,
  `n_from` varchar(100) NOT NULL,
  `notice` varchar(100) NOT NULL,
  `n_date` varchar(100) NOT NULL,
  PRIMARY KEY (`n_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice_details`
--

INSERT INTO `notice_details` (`n_id`, `n_from`, `notice`, `n_date`) VALUES
(1, 'Admin', 'Testing Notice from admin', '2022-8-27');

-- --------------------------------------------------------

--
-- Table structure for table `usercomplain_details`
--

DROP TABLE IF EXISTS `usercomplain_details`;
CREATE TABLE IF NOT EXISTS `usercomplain_details` (
  `c_id` int(100) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) NOT NULL,
  `w_id` varchar(100) NOT NULL,
  `c_details` varchar(100) NOT NULL,
  `c_date` varchar(100) NOT NULL,
  `c_status` varchar(100) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usercomplain_details`
--

INSERT INTO `usercomplain_details` (`c_id`, `u_id`, `w_id`, `c_details`, `c_date`, `c_status`) VALUES
(1, 'sangeeta@gmail.com', 'info.sakhiorg@gmail.com', 'Woman Harassment  and Beating', '2022-8-27', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

DROP TABLE IF EXISTS `user_details`;
CREATE TABLE IF NOT EXISTS `user_details` (
  `u_id` int(100) NOT NULL AUTO_INCREMENT,
  `u_fname` varchar(100) NOT NULL,
  `u_lname` varchar(100) NOT NULL,
  `u_mobile` varchar(100) NOT NULL,
  `u_email` varchar(100) NOT NULL,
  `u_city` varchar(100) NOT NULL,
  `u_designation` varchar(100) NOT NULL,
  `u_photo` varchar(100) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`u_id`, `u_fname`, `u_lname`, `u_mobile`, `u_email`, `u_city`, `u_designation`, `u_photo`) VALUES
(1, 'Sangeeta', 'Mishra', '9517531230', 'sangeeta@gmail.com', 'Chikkodi', 'House Wife', 'adult-women.png'),
(2, 'Laxmi', 'Patil', '9966447788', 'laxmi@gmail.com', 'Nipani', 'Student', 'noimg.png');

-- --------------------------------------------------------

--
-- Table structure for table `wwa_details`
--

DROP TABLE IF EXISTS `wwa_details`;
CREATE TABLE IF NOT EXISTS `wwa_details` (
  `w_id` int(100) NOT NULL AUTO_INCREMENT,
  `w_name` varchar(100) NOT NULL,
  `w_email` varchar(100) NOT NULL,
  `w_mobile` varchar(12) NOT NULL,
  `w_establishdate` varchar(100) NOT NULL,
  `w_divisionname` varchar(100) NOT NULL,
  `w_city` varchar(100) NOT NULL,
  `w_associationlogo` varchar(100) NOT NULL,
  `w_vdoc` varchar(100) NOT NULL,
  `w_status` varchar(100) NOT NULL,
  PRIMARY KEY (`w_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wwa_details`
--

INSERT INTO `wwa_details` (`w_id`, `w_name`, `w_email`, `w_mobile`, `w_establishdate`, `w_divisionname`, `w_city`, `w_associationlogo`, `w_vdoc`, `w_status`) VALUES
(1, 'Sakhi', 'info.sakhiorg@gmail.com', '9988776655', '2021-12-25', 'Main', 'Chikkodi', 'download.png', 'nodoc.pdf', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `wwa_works`
--

DROP TABLE IF EXISTS `wwa_works`;
CREATE TABLE IF NOT EXISTS `wwa_works` (
  `ww_id` int(100) NOT NULL AUTO_INCREMENT,
  `w_id` varchar(100) NOT NULL,
  `w_title` varchar(100) NOT NULL,
  `w_description` varchar(100) NOT NULL,
  `w_photo` varchar(100) NOT NULL,
  `w_date` varchar(100) NOT NULL,
  PRIMARY KEY (`ww_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wwa_works`
--

INSERT INTO `wwa_works` (`ww_id`, `w_id`, `w_title`, `w_description`, `w_photo`, `w_date`) VALUES
(1, 'info.sakhiorg@gmail.com', 'Cloth Donation ', 'Cloth Donation by our Team', 'work-done.jpg', '2022-8-27'),
(2, 'info.sakhiorg@gmail.com', 'Donation', 'Donation', 'donation.jpg', '2022-8-27');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
